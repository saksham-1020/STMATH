def mean(data):
    if not data:
        return 0.0
    return sum(data) / len(data)

def variance(data):
    if not data:
        return 0.0
    m = mean(data)
    return sum((x - m) ** 2 for x in data) / len(data)

def std_dev(data):
    return variance(data) ** 0.5

def z_score(x, mean_value, std_value):
    if std_value == 0:
        raise ValueError("Standard deviation must be non-zero.")
    return (x - mean_value) / std_value

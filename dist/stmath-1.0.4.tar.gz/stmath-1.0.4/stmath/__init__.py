# STMATH package initializer

# Core Math
from .core import add, sub, mul, div, square, cube, sqrt, power

# Statistics
from .stats import mean, variance, std_dev, z_score

__all__ = [
    # Core
    "add", "sub", "mul", "div", "square", "cube", "sqrt", "power",
    # Stats
    "mean", "variance", "std_dev", "z_score",
]
